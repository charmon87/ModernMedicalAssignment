﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ModernMedicalAssignment
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int counter = 1; counter <= 100; counter++)
            {
                bool isDivisibleByThree = (counter % 3 == 0);
                bool isDivisibleByFive = (counter % 5 == 0);

                if (isDivisibleByThree && isDivisibleByFive)
                {
                    Console.WriteLine("{0}{1}", ModernMedicalAssignment.Properties.Resources.DivisibleByThreeLabel, ModernMedicalAssignment.Properties.Resources.DivisibleByFiveLabel);
                }
                else if (isDivisibleByThree)
                {
                    Console.WriteLine(ModernMedicalAssignment.Properties.Resources.DivisibleByThreeLabel);
                }
                else if (isDivisibleByFive)
                {
                    Console.WriteLine(ModernMedicalAssignment.Properties.Resources.DivisibleByFiveLabel);
                }
                else
                {
                    Console.WriteLine(string.Format("{0}", counter));
                }
            }

            // I recognize the fact that the next three lines of code are not part of the original assigment.
            Console.WriteLine();
            Console.WriteLine(ModernMedicalAssignment.Properties.Resources.ContinuePrompt);
            Console.Read();
        }
    }
}
